package abstractquestion;

public abstract class Shape {
    abstract double calculateArea();

    //public abstract void validateDimensions() throws NegativeNumberException;
}
