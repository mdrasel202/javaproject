package atm;

public class Test extends Account{
    public static void main(String[] args) {
        OptionMenu ins = new OptionMenu();
        ins.getLogin();
    }
}
